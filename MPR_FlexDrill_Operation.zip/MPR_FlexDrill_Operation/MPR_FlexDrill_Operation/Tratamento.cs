﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace MPR_Operation
{
	internal class Leitura
	{
		public decimal ComprimentoMPR { get; set; }
		public decimal LarguraMPR { get; set; }
		public decimal EspessuraMPR { get; set; }
		public int Contador140 { get; set; }
		public object Arquivos(string arquivos)
		{
			string pastaLeitura = Directory.GetCurrentDirectory();
			string[] arquivosMPR = Directory.GetFiles(pastaLeitura, "*.mpr", SearchOption.AllDirectories);
			string arquivoTemporario = Path.GetTempFileName();
			List<string> estruturampr = new List<string>();

			foreach (var mpr in arquivosMPR) //Elimina KM
			{
				string[] leituraLinhaMpr = File.ReadAllLines(mpr);

				StreamWriter escritaMPR = new StreamWriter(arquivoTemporario);
				{
					for (int i = 0; i < leituraLinhaMpr.Length; i++)
					{
						if (leituraLinhaMpr[i].StartsWith("<101 \\Kommentar\\")) { }
						else if (leituraLinhaMpr[i].StartsWith("KM=") && leituraLinhaMpr[i].Contains("KM=\"Length X\"")) { escritaMPR.WriteLine(leituraLinhaMpr[i]); }
						else if (leituraLinhaMpr[i].StartsWith("KM=") && leituraLinhaMpr[i].Contains("KM=\"Width Y\"")) { escritaMPR.WriteLine(leituraLinhaMpr[i]); }
						else if (leituraLinhaMpr[i].StartsWith("KM=") && leituraLinhaMpr[i].Contains("KM=\"Thickness =Z\"")) { escritaMPR.WriteLine(leituraLinhaMpr[i]); }
						else if (leituraLinhaMpr[i].StartsWith("KM=") && leituraLinhaMpr[i].Contains("Z+\"")) 
						{
							string linhazmais = leituraLinhaMpr[i];
							escritaMPR.WriteLine("<101 \\Kommentar\\"); 
							escritaMPR.WriteLine(linhazmais); 
						}
						else if (leituraLinhaMpr[i].StartsWith("KM=") && !leituraLinhaMpr[i].Contains("Length X")){	}
						else if (leituraLinhaMpr[i].StartsWith("KM=") && !leituraLinhaMpr[i].Contains("Width Y")) { }
						else if	(leituraLinhaMpr[i].StartsWith("KM=") && !leituraLinhaMpr[i].Contains("Thickness =Z")) { }
						else 
						{
							escritaMPR.WriteLine(leituraLinhaMpr[i]);
						}
					}
				}
				escritaMPR.Close();
				escritaMPR.Dispose();

				File.Delete(mpr);
				File.Copy(arquivoTemporario, mpr);
			}


			foreach (var mpr in arquivosMPR) //Trata operacoes
			{
				string[] leituraLinhaMpr = File.ReadAllLines(mpr);

				for (int i = 0; i < leituraLinhaMpr.Length; i++)
				{
					estruturampr.Add(leituraLinhaMpr[i]);
				}

				StreamWriter escritaMPR = new StreamWriter(arquivoTemporario);
				{
					for (int i = 0; i < estruturampr.Count; i++)
					{
						if (estruturampr[i].StartsWith("<140 \\Vektorfraesen\\")) //Trata macro 140 >> Y- >> Y+ no arquivo mpr
						{
							Contador140 = i;

							do
							{
								if (estruturampr[Contador140 - 1].StartsWith("Y=-"))
								{
									string linhaYajustada = estruturampr[Contador140 - 1].ToString().Replace("Y=-", "Y=");
									estruturampr[Contador140 - 1] = linhaYajustada;
								}
								Contador140--;
							} while (!estruturampr[Contador140].ToString().StartsWith("]"));
						}
					}

					for (int i = 0; i < estruturampr.Count; i++)
					{
						if (estruturampr[i].StartsWith("l=")) //Valor de L
						{
							string valorComp = estruturampr[i].Replace("l=", "");
							string valorCompNumero = valorComp.Replace("\"", "");
							ComprimentoMPR = Convert.ToDecimal(valorCompNumero);
							escritaMPR.WriteLine(estruturampr[i]);
						}
						else if (estruturampr[i].StartsWith("la=")) //Valor de LA
						{
							string valorLarg = estruturampr[i].Replace("la=", "");
							string valorLargNumero = valorLarg.Replace("\"", "");
							LarguraMPR = Convert.ToDecimal(valorLargNumero);
							escritaMPR.WriteLine(estruturampr[i]);
						}
						else if (estruturampr[i].StartsWith("e=")) //Valor de E
						{
							string valorEsp = estruturampr[i].Replace("e=", "");
							string valorEspNumero = valorEsp.Replace("\"", "");
							EspessuraMPR = Convert.ToDecimal(valorEspNumero);
							escritaMPR.WriteLine(estruturampr[i]);
						}
						else if (estruturampr[i].StartsWith("YA=\"-") && estruturampr[i - 3].Contains("Z+\"")) //Trata 102 >> 131
						{
							string valorlinhatratada = estruturampr[i].Replace("YA=\"-", "YA=\"");
							escritaMPR.WriteLine(valorlinhatratada);
						}
						else if (estruturampr[i].StartsWith("<102 \\BohrVert\\") && estruturampr[i-1].Contains("Z+\"")) //Trata 102 >> 131
						{
							string valorlinhatratada = estruturampr[i].Replace("<102 \\BohrVert\\", "<131 \\UfluBohr\\");
							escritaMPR.WriteLine(valorlinhatratada);
						}
						else if (estruturampr[i].StartsWith("KO=\"0\"") && estruturampr[i - 1].StartsWith("F_=\"STANDARD\"")) { } //Cancela KO do furo
						else if (estruturampr[i].StartsWith("ZA=\"@0\"") && estruturampr[i - 10].StartsWith("<105 \\Konturfraesen\\") && estruturampr[i - 17].StartsWith("Z=")) //Trata ZA do comando 105
						{
							decimal valorZ = Convert.ToDecimal(estruturampr[i - 17].Replace("Z=", ""));
							decimal novovalorZ = EspessuraMPR - valorZ;
							string novovalorZA = @"ZA=" + "\"" + novovalorZ.ToString() + "\"";
							escritaMPR.WriteLine(novovalorZA);
						}
						else if (estruturampr[i].StartsWith("ZA=\"@0\"") && estruturampr[i - 10].StartsWith("<105 \\Konturfraesen\\") && estruturampr[i - 19].StartsWith("Z=")) //Trata ZA do comando 105
						{
							decimal valorZ = Convert.ToDecimal(estruturampr[i - 19].Replace("Z=", ""));
							decimal novovalorZ = EspessuraMPR - valorZ;
							string novovalorZA = @"ZA=" + "\"" + novovalorZ.ToString() + "\"";
							escritaMPR.WriteLine(novovalorZA);
						}
						else if (estruturampr[i].StartsWith("ZM=\"@0\"") && estruturampr[i - 10].StartsWith("<140 \\Vektorfraesen\\") && estruturampr[i - 17].StartsWith("Z=")) //Trata ZM do comando 140
						{
							decimal valorZ = Convert.ToDecimal(estruturampr[i - 17].Replace("Z=", ""));
							decimal novovalorZ = EspessuraMPR - valorZ;
							string novovalorZA = @"ZM=" + "\"" + novovalorZ.ToString() + "\"";
							escritaMPR.WriteLine(novovalorZA);
						}
						else if (estruturampr[i].StartsWith("ZM=\"@0\"") && estruturampr[i - 10].StartsWith("<140 \\Vektorfraesen\\") && estruturampr[i - 19].StartsWith("Z=")) //Trata ZM do comando 140
						{
							decimal valorZ = Convert.ToDecimal(estruturampr[i - 19].Replace("Z=", ""));
							decimal novovalorZ = EspessuraMPR - valorZ;
							string novovalorZA = @"ZM=" + "\"" + novovalorZ.ToString() + "\"";
							escritaMPR.WriteLine(novovalorZA);
						}
						else if (estruturampr[i].StartsWith("<140 \\Vektorfraesen\\")) //Trata macro 140 >> 113
						{
							string valorlinhatratada = estruturampr[i].Replace("<140 \\Vektorfraesen\\", "<113 \\Router from below\\");
							escritaMPR.WriteLine(valorlinhatratada);
						}
						else
						{
							escritaMPR.WriteLine(estruturampr[i]);
						}
					}
				}
				escritaMPR.Close();
				escritaMPR.Dispose();

				File.Delete(mpr);
				File.Copy(arquivoTemporario, mpr);
			}
			return arquivos;
		}

	}
}
